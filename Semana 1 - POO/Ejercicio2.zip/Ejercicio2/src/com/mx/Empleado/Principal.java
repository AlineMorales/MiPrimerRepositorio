package com.mx.Empleado;

public class Principal {
	
	public static void main(String args[] ) {
		//instancia el objeto 
		Empleado emp1 = new Empleado("David", "Gonzales", "Jimenez", 8527418754L, 58, 6500.13);
		Empleado emp2 = new Empleado("Jose","Moreno","Hernandez",735818754L,25,2500.13 );
		Empleado emp3 = new Empleado("Axel", "Garcia", "Oropeza", 5478620158L, 45, 30000.50);
		Empleado emp4 = new Empleado("Jose", "Ramirez", "Diaz", 5478764654L, 38, 9500.30);
		Empleado emp5 = new Empleado("Rafael", "Medina", "Lopez", 589503414L, 30, 29000.55);
		Empleado emp6 = new Empleado(" Jose", " Anaya ", " Sanchez" ,7714043645L, 23, 15000);
		Empleado emp7 = new Empleado("Laura", "Hernandez", "Ruiz", 9982345678L, 32, 8200.50);
		
		//objeto auxiliar
		Empleado empAux = null;
		
		//Instanciar la clase de implementacion para poder ocupar todos los metodos declarados 
		Implementacion imp = new Implementacion();
		
		//alamcenar todos los ojetos en la lista 
		imp.create(0, emp1);
		imp.create(1, emp2);
		imp.create(2, emp3);
		imp.create(3, emp4);
		imp.create(4, emp5);
		imp.create(5, emp6);
		imp.create(6, emp7);
		
		//mostrar
		imp.read();
		
		//buscar
		empAux = imp.buscar(1);
		System.out.println("Elemento encontrado: " + empAux );
		
		//editar
		empAux = imp.buscar(1);
		empAux.setNombre("Julian");
		empAux.setSueldo(85);
		imp.update(1, emp2);
		System.out.println("Elemento editado " + empAux);
		
		//eliminar
		imp.delete(2);
		imp.read();
		
		//contar
		imp.contar();
	
	}

}
